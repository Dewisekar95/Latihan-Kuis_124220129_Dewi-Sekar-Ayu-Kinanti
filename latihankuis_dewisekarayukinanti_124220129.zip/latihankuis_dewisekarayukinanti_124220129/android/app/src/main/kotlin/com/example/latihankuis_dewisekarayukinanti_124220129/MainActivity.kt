package com.example.latihankuis_dewisekarayukinanti_124220129

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
